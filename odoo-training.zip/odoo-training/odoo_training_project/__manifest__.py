# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

{
    'name': 'Odoo Training Project',
    'category': 'Sales',
    'version': '18.0.0.0',
    'author': 'Bizople Solutions Pvt. Ltd.',
    'website': 'https://www.bizople.com',
    'summary': 'Odoo Training Project',
    'description': """Odoo Training Project""",
    'depends': [
        'sale_management',
    ],
    'data': [
        "security/ir.model.access.csv",
        "views/hotel_staff_views.xml",
        "views/menuitem.xml",
    ],
    'demo': [
    ],
    'assets': {
        'web.assets_backend':[
            # "/odoo_training_project/static/src/scss/aerohome_page.scss",
        ],
    },
    
    'installable': True,
    'auto_install': False,
    'application': False,
    'license': 'OPL-1',
}
