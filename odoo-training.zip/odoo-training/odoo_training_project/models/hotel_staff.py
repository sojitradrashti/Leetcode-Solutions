# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

from odoo import models, fields


class HotelStaff(models.Model):
    _name = "hotel.staff"
    _description = "Hotel Staff"

    name = fields.Char("Name", required=True)
    email = fields.Char("Email")
    birthdate = fields.Datetime(
        string='Birth Date',
    )
