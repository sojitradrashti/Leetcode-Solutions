# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

{
    'name': 'Hostel Management System',
    'category': 'Sales',
    'version': '18.0.0.0',
    'author': 'Bizople Solutions Pvt. Ltd.',
    'website': 'https://www.bizople.com',
    'summary': 'Hostel Management System',
    'description': """Hostel Management System""",
    'depends': [
        'base',
    ],
    'data': [
        "security/ir.model.access.csv",
        "views/student_registration_views.xml",
        "views/hostel_facilities_views.xml",
        "views/attendance_system_views.xml",
        "views/complaint_management_views.xml",
        "views/maintainance_repair_views.xml",
        "views/payment_system_views.xml",
        "views/menuitem.xml",
    ],
    'demo': [
    ],
    'assets': {
        'web.assets_backend':[
            # "/odoo_training_project/static/src/scss/aerohome_page.scss",
        ],
    },
    
    'installable': True,
    'auto_install': False,
    'application': False,
    'license': 'OPL-1',
}
