# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

from odoo import models, fields


class AttendanceSystem(models.Model):
    _name = "attendance.system"
    _description = "Attendance System"

    student_id = fields.Many2one('student.details',string="Student Name", required=True)
    phone = fields.Char(related='student_id.phone', string="Phone", readonly=True)
    student_room_id = fields.Char(related='student_id.room_number', string="Student Room", store=True, readonly=True)
    entry_date = fields.Datetime(string="Entry Date") 
    exit_date = fields.Datetime(string="Exit Date") 
    
    
    
