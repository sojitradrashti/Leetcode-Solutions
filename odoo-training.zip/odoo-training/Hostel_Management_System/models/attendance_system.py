# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

from odoo import models, fields


class AttendanceSystem(models.Model):
    _name = "attendance.system"
    _description = "Attendance System"

    name = fields.Many2one('student.registration',string="Student Name", required=True)
    student_room = fields.Many2one('hostel.facilities',string = "Student Room",required=True,readonly=True)
    attendance_date = fields.Date(string="Attendance Date") 
    phone = fields.Char(string="Phone Number")
    
    
