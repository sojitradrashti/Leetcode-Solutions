# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

from odoo import models, fields


class MaintainanceRepair(models.Model):
    _name = "maintainance.repair"
    _description = "Maintainance Repair"

    student_room = fields.Many2one('hostel.facilities',tring = "Student Room", required=True)
    request_date = fields.Date(string="Request Date") 
    description_details = fields.Char(string="Issue Details")
    maintainance_status=fields.Selection(string="Maintain Status",
        selection=[
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ],default='completed')
    phone = fields.Char(string="Phone Number")
    
    