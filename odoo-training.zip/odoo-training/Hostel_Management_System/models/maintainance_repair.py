# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

from odoo import models, fields


class MaintainanceRepair(models.Model):
    _name = "maintainance.repair"
    _description = "Maintainance Repair"

    student_id = fields.Many2one('student.details',string="Student Name", required=True)
    student_room = fields.Char(related='student_id.room_number',string = "Student Room", required=True)
    request_date = fields.Date(string="Request Date") 
    issue_type = fields.Selection(string="Issue Type",
        selection=[
        ('plumbing', 'Plumbing'),
        ('electrical', 'Electrical'),
        ('internet','Internet'),
        ],default='internet')
    description_details = fields.Char(string="Issue Details")
    maintainance_status=fields.Selection(string="maintainance Status",
        selection=[
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ],default='completed')
    resolution_date=fields.Date(string="Resolution Date")
    
    