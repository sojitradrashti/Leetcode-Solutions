# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

from odoo import models, fields


class StudentRegistration(models.Model):
    _name = "student.registration"
    _description = "Student Registration"

    name = fields.Char("Name", required=True)
    email = fields.Char("Email")
    birthdate = fields.Date(
        string='Birth Date',
    )
    phone = fields.Char(string="Phone Number")
    course_name = fields.Char(string="Course Name")
    adhar_number = fields.Char(string="Adhar Number")
    arrival_date = fields.Date(
        string='Arrival date',
    )
    address = fields.Text(string="Address")