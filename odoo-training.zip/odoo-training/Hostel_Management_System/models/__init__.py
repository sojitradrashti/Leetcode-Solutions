# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details


from . import student_registration
from . import hostel_facilities
from . import attendance_system
from . import complaint_management
from . import maintainance_repair
from . import payment_system


