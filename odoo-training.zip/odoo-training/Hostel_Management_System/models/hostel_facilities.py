# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

from odoo import models, fields


class HostelFacilities(models.Model):
    _name = "hostel.facilities"
    _description = "Hostel Facilities"

    student_id = fields.Many2one("student.registration",string="Student Name", required=True)
    student_room = fields.Char(string = "Student Room",required=True)
    room_category = fields.Selection([
        ('ac', 'AC'),
        ('non_ac', 'Non-AC')
    ], string="Room Category", required=True, default='non_ac')
    room_type = fields.Selection([
        ('shared', 'Shared'),
        ('single', 'Single')
    ], string="Room Type", required=True, default='shared')
    # phone = fields.Char(related='student_id.phone', string="Phone Number", readonly=True)
    