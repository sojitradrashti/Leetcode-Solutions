# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

from odoo import models, fields


class HostelFacilities(models.Model):
    _name = "hostel.facilities"
    _description = "Hostel Facilities"

    room_category = fields.Selection([
        ('ac', 'AC'),
        ('non_ac', 'Non-AC')
    ], string="Room Category", required=True, default='non_ac')
    room_type = fields.Selection([
        ('single', 'Single'),
        ('2 sharing', '2 Sharing'),
        ('3 shared', '3 Sharing'),
        ('4 shared', '4 Sharing'),
        ('5 shared', '5 Sharing'),
    ], string="Room Type", required=True, default='single')
    additional_services = fields.Char(string="Additional Services")
    laundry = fields.Boolean(string="Laundry")
    wifi = fields.Boolean(string="WiFi")   