# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

from odoo import models, fields


class PaymentSystem(models.Model):
    _name = "payment.system"
    _description = "Payment System"

    name = fields.Many2one('student.registration',string="Student Name", required=True)
    payment_date = fields.Date(string="Request Date") 
    fee_invoice_id = fields.Char(string="Invoice Id")
    amount = fields.Char(string="Amount")
    payment_method =fields.Selection(string="Payment Method",
        selection=[
        ('cash', 'Cash'),
        ('bank_transfer', 'Bank Transfer'),
        ('credit_card', 'Credit Card'),
        ('online', 'Online Payment'),
        ],default='cash')
    payment_status=fields.Selection(string="Payment Status",
        selection=[
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ],default='completed')
    
    