# -*- coding: utf-8 -*-
# Developed by Bizople Solutions Pvt. Ltd.
# See LICENSE file for full copyright and licensing details

from odoo import models, fields

class ComplaintManagement(models.Model):
    _name = "complaint.management"
    _description = "Complaint Management"

    student_id = fields.Many2one('student.details',string="Student Name", required=True)
    student_room_id = fields.Char(related='student_id.room_number',string = "Student Room")
    complain_date = fields.Date(string="Complain Date") 
    complaint_details = fields.Char(string="Complaint Details")
    complaint_status=fields.Selection([
        ('pending', 'Pending'),
        ('resolved', 'Resolved'),
    ], string="Complaint Status", required=True, default='resolved')
    
    
    